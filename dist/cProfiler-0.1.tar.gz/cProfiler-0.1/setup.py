from setuptools import setup

setup(name='cProfiler',
      version='0.1',
      description='Django middleware based on cProfile',
      author='Somcha',
      author_email='somesh.08.96@gmail.com',
      license='MIT',
      packages=['Profiler'],
      zip_safe=False)
